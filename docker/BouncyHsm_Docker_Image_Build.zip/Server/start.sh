#!/bin/bash

set -e

echo "Starting BouncyHSM..."
echo "You can override environment variables (USER_PIN, SO_PIN, SLOT_LABEL, SLOT_SERIAL, and SLOT_DESCRIPTION) by passing them during container startup (option '-e')."

# Start the BouncyHSM service in the background
dotnet BouncyHsm.dll &

# Capture the PID of the background process
SERVICE_PID=$!

# Wait for the BouncyHSM service to start by checking the health endpoint
echo "Waiting for BouncyHSM to be ready..."

# Timeout after 30 seconds if the service is not ready
timeout=30
elapsed=0
interval=1

while ! curl -s --head http://localhost:8500 | grep "200 OK" > /dev/null; do
  sleep $interval
  elapsed=$((elapsed + interval))
  if [ $elapsed -ge $timeout ]; then
    echo "Timeout waiting for BouncyHSM to start."
    kill $SERVICE_PID
    exit 1
  fi
done

echo "BouncyHSM is ready."

# Create the slot and check for errors
if ! dotnet cli/BouncyHsm.Cli.dll slot create -d "$SLOT_DESCRIPTION" -l "$SLOT_LABEL" -s "$SLOT_SERIAL" -u "$USER_PIN" -q "$SO_PIN" -e "http://localhost:8500/"; then
  echo "Failed to create the slot. Exiting."
  kill $SERVICE_PID
  exit 1
fi

# Wait for the service to exit
wait $SERVICE_PI