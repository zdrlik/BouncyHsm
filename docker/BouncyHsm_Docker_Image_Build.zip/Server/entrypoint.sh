#!/bin/bash

set -e

echo "Starting BouncyHSM..."
echo "You can override environment variables (USER_PIN, SO_PIN, TOKEN_LABEL , TOKEN_SERIAL, and SLOT_DESCRIPTION) by passing them during container startup (option '-e')."

: ${USER_PIN:=1111}
: ${SO_PIN:=12345678}
: ${SLOT_DESCRIPTION:=TestSlot01}
: ${TOKEN_LABEL:=TestToken01}
: ${TOKEN_SERIAL:=A22E66EB220B00C8}

echo "USER_PIN=$USER_PIN"
echo "SO_PIN=$SO_PIN"
echo "SLOT_DESCRIPTION=$SLOT_DESCRIPTION"
echo "TOKEN_LABEL=$TOKEN_LABEL"
echo "TOKEN_SERIAL=$TOKEN_SERIAL"

# Start the BouncyHSM service in the background
dotnet BouncyHsm.dll &

# Capture the PID of the background process
SERVICE_PID=$!

# Wait for the BouncyHSM service to start by checking the health endpoint
echo "Waiting for BouncyHSM to be ready..."

# Timeout after 30 seconds if the service is not ready
timeout=30
elapsed=0
interval=1

while ! curl -s --head http://localhost:8080 | grep "200 OK" > /dev/null; do
  sleep $interval
  elapsed=$((elapsed + interval))
  if [ $elapsed -ge $timeout ]; then
    echo "Timeout waiting for BouncyHSM to start."
    kill $SERVICE_PID
    exit 1
  fi
done

echo "BouncyHSM is ready."

# Create the slot and check for errors
if ! dotnet /opt/BouncyHsm/cli/BouncyHsm.Cli.dll slot create -d "$SLOT_DESCRIPTION" -l "$TOKEN_LABEL" -s "$TOKEN_SERIAL" -u "$USER_PIN" -q "$SO_PIN" -e "http://localhost:8080/"; then
  echo "Failed to create the slot. Exiting."
  kill $SERVICE_PID
  exit 1
fi

# Wait for the service to exit
wait $SERVICE_PI