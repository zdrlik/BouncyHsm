#!/bin/bash


echo "Starting BouncyHSM..."
echo "You can override environment variables (USER_PIN, SO_PIN, SLOT_LABEL and SLOT_DESCRIPTION) by passing them during container startup (option '-e')."
cd /opt/BouncyHsm/bin/

# Start the BouncyHSM service
dotnet BouncyHsm.dll &

# Wait for the service to be up (add a sleep or health check if necessary)
sleep 5

# Create the slot
dotnet cli/BouncyHsm.Cli.dll slot create -d "$SLOT_DESCRIPTION" -l "$SLOT_LABEL" -u "$USER_PIN" -q "$SO_PIN" -e "http://localhost:8500/"

# Keep the container running (replace with the appropriate way to keep the service running if needed)
tail -f /dev/null
